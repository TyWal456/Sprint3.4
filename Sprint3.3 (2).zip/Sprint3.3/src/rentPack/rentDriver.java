/*Name: Tyrell Walrond
Course: CSC 243
Instructor: Professor Demarco
Filename: rentDriver.java
Purpose: The purpose of this file is to facilitate methods using constructs for 
		object orientation for a ficticious vacation resort*/

package rentPack;
import java.util.*;
import java.lang.*;



public class rentDriver{
	
	
	

public static ArrayList<rentDriver> orders = new ArrayList<rentDriver>();

public static void main(String args[]){
	
	Scanner in = new Scanner(System.in);
	char choice;
	int orderNo = 1;
	
	
	Customer rentGrab = new Customer();
	RentObj objGrab = new RentObj();
	Boat boatObj = new Boat();
	Chair chairObj = new Chair();
	Umbrella umbrellaObj = new Umbrella();
	
	
        rentGrab.getContactInfo();
		System.out.println("     Welcome to Victoria's Vacation Renting Shack!      \n");
     
        
        
	for(int i = 0; i < 5; i++){
		System.out.println("Order#: 00"+ orderNo + "\n\n");
        
		orderNo++;
		
		System.out.println("  What equipment type would you like to rent?: ");
		System.out.println("  a. Boats  " + '\n' + "  b. Chairs  " + '\n' + "  c. Umbrellas ");
		choice = in.next().charAt(0);

			switch(choice){
				 
				 case 'a':
					boatObj.boatOrder();
					break;
				 case 'b':
					chairObj.chairOrder();
					break;
				 case 'c':
					umbrellaObj.umbrellaOrder();
			}
			
		}
	}
}